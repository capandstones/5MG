package main;

import frame.BeginPanel;
import frame.FrameBase;
import frame.FrameSearch;

public class Main {
	public static void main(String[] args) {

		FrameBase.getInstance(new BeginPanel());

	}

}