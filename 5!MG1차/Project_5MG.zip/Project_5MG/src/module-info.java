/**
 * 
 */
/**
 * @author user
 *
 */
module Project_5MG {
	requires java.desktop;
}