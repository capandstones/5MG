package frame;

import javax.swing.JFrame;
import element.UserInfo;

public class Cross extends JFrame {

	public Cross(UserInfo userInfo) {

		JFrame f = new JFrame();

		f.setVisible(true);

	}

}
